package spark.batch.tp21;

import org.apache.spark.api.java.*;
import org.apache.spark.SparkConf;
import scala.Tuple2;

public class WordCountTask {
    public static void main(String[] args) {

        if (args.length < 2) {
            System.err.println("Usage: WordCountTask <input> <output>");
            System.exit(1);
        }

        SparkConf conf = new SparkConf().setAppName("WordCountTask");
        JavaSparkContext sc = new JavaSparkContext(conf);

        JavaRDD<String> text = sc.textFile(args[0]);

        JavaPairRDD<String, Integer> counts =
                text.flatMap(line -> java.util.Arrays.asList(line.split(" ")).iterator())
                    .mapToPair(word -> new Tuple2<>(word, 1))
                    .reduceByKey(Integer::sum);

        counts.saveAsTextFile(args[1]);

        sc.close();
    }
}
