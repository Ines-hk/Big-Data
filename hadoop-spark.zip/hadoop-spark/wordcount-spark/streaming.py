from pyspark.sql import SparkSession
from pyspark.sql.functions import explode, split

spark = SparkSession.builder \
    .appName("StructuredStreamingWordCount") \
    .master("local[*]") \
    .getOrCreate()

lines = spark.readStream \
    .format("socket") \
    .option("host", "172.0.0.0") \
    .option("port", 9998) \
    .load()

words = lines.select(
    explode(split(lines.value, "\\s+")).alias("word")
)

wordCounts = words.groupBy("word").count()

query = wordCounts.writeStream \
    .outputMode("complete") \
    .format("console") \
    .option("truncate", "false") \
    .start()

query.awaitTermination()
