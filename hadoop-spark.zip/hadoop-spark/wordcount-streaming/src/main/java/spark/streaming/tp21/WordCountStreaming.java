package spark.streaming.tp21;

import org.apache.spark.SparkConf;
import org.apache.spark.streaming.Duration;
import org.apache.spark.streaming.api.java.*;
import scala.Tuple2;

import java.util.Arrays;

public class WordCountStreaming {

    public static void main(String[] args) throws InterruptedException {

        if (args.length < 2) {
            System.err.println("Usage: WordCountStreaming <hostname> <port>");
            System.exit(1);
        }

        SparkConf conf = new SparkConf()
                .setAppName("WordCountStreaming")
                .setMaster("local[2]");

        JavaStreamingContext jssc =
                new JavaStreamingContext(conf, new Duration(5000));

        JavaReceiverInputDStream<String> lines =
                jssc.socketTextStream(args[0], Integer.parseInt(args[1]));

        JavaPairDStream<String, Integer> counts =
                lines.flatMap(x -> Arrays.asList(x.split("\\s+")).iterator())
                     .mapToPair(word -> new Tuple2<>(word, 1))
                     .reduceByKey(Integer::sum);

        counts.print();

        jssc.start();
        jssc.awaitTermination();
    }
}
